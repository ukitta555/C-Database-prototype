#pragma once

#include <string>
#include <iostream>
std::string ParseEvent(std::istream& is);