#pragma once

enum class LogicalOperation
{
	And,
	Or
};